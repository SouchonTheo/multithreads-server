package linda.search.Request1;

public enum Code {
    Request, // Request, UUID, String
    Value, // Value, String
    Result, // Result, UUID, String, Int
    Searcher, // Result, "done", UUID
}
